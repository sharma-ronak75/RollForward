# Roll Forward – Mobility Aid Donation Drive

Node.js app with **no npm dependencies** (built-in `http`, `crypto`, `fs`). Needs Node 18+.

```bash
node server.js          # http://localhost:3000
npm test                # end-to-end API checks
```

First start creates `data/db.json` (5 sample beneficiaries, everything at zero) and an admin account:
`admin@rollforward.local` with a random password printed once in the console.
Set `ADMIN_EMAIL` / `ADMIN_PASSWORD` before first start to choose your own.

Environment: `PORT`, `DATA_DIR`, `SESSION_SECRET`, `COOKIE_SECURE=1` (behind HTTPS), `TRUST_PROXY=1` (behind a proxy).

## What the backend does
- Accounts: scrypt-hashed passwords, signed HTTP-only session cookie, change password, delete account.
- Donations: pick an item and quantity, or enter any amount (min ₹100). Server-side pricing and validation; money goes to the chosen
  beneficiary, then to others needing the same aid (any aid for amount-only gifts), closest to complete first, then the general fund.
  Receipts, history, anonymous gifts, dedications. A processing/success popup with confetti follows every gift or pledge.
- Applications: public form with reference number + tracker; admin review (Received → Referral checked → Assessed → Approved/Declined).
  Approving requires a privacy-safe public story and creates the beneficiary listing.
- Delivery updates: admin posts updates / marks funded aids delivered; donors see them under "My giving".
- "Donate Us" (accessory / in-kind) donations: pledge cushions, walking aids, used wheelchairs etc. with contact number, full address, hand-over method and condition; reference + email tracking; admin review (Pledged → Arrangement confirmed → Received → Accepted → Distributed / Declined) and CSV export.
- Money gifts now require a contact number and billing address, shown on the receipt and in the admin export.
- Volunteer shifts with capacity, join/cancel, interest register; admin can add shifts.
- Admin console: totals, 14-day chart, outstanding need, donations table, CSV export (formula-injection safe).
- Hardening: per-route rate limits, JSON-only writes + same-origin check, CSP and security headers, path-traversal-safe static server.

## Not included
Real payments (`POST /api/donations` is where a payment provider would go) and email sending.
# RollForward
