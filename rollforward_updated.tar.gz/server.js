'use strict';
/* Roll Forward – Node.js backend. Zero dependencies (http, crypto, fs only).
   Data is persisted to data/db.json. Run: node server.js */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { promisify } = require('util');
const scrypt = promisify(crypto.scrypt);

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const SESSION_DAYS = 14;

fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------------------------------------------------------------- catalogue */
const AIDS = {
  chair:  { name: 'Wheelchair',      label: 'Wheelchair',      price: 7125,  note: 'Funds one full wheelchair' },
  crutch: { name: 'Crutches',        label: 'Crutches',        price: 3800,  note: 'A fitted pair of crutches' },
  trike:  { name: 'Tricycle',        label: 'Tricycle',        price: 22800, note: 'Funds one full tricycle' },
  limb:   { name: 'Artificial Limb', label: 'Artificial Limb', price: 14250, note: 'Limb with first fitting' },
  cane:   { name: 'White Cane',      label: 'White Cane',      price: 500,   note: 'Folding cane for walking safely' },
};
const GENERAL = 'general'; // amount-only gifts that are not tied to one aid
const itemLabel = d => (d.option === GENERAL ? 'General donation' : AIDS[d.option].label);
const MIN_GIFT = 100, MAX_GIFT = 1000000;
const INDIAN_STATES = ['Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Chandigarh', 'Puducherry'];
const aidKeyByName = name => Object.keys(AIDS).find(k => AIDS[k].name === name);
const DISABILITIES = ['Amputee', 'Paralysis', 'Blindness', 'Cerebral palsy', 'Other'];
const ROLES = ['donor', 'beneficiary', 'volunteer'];
const VOLUNTEER_ROLES = ['Delivery and logistics', 'Event support', 'Awareness and outreach', 'Fundraising'];
const APP_STATUSES = ['Received', 'Referral checked', 'Assessed', 'Approved', 'Declined'];
const ACCESSORY_TYPES = ['Wheelchair cushion', 'Walking stick / cane', 'Walker / rollator', 'Used wheelchair (working)', 'Crutches (used)', 'Prosthetic components', 'Braces and splints', 'Wheelchair gloves', 'Portable ramp', 'Other'];
const CONDITIONS = ['New', 'Like new', 'Good', 'Fair'];
const METHODS = ['Drop off at a partner clinic', 'Pick up from my address', 'I will ship it'];
const IK_STATUSES = ['Pledged', 'Arrangement confirmed', 'Received', 'Accepted', 'Distributed', 'Declined'];
const IK_RECEIVED = ['Received', 'Accepted', 'Distributed'];

/* ----------------------------------------------------------------- database */
let db;
let saveTimer = null;

const isoDay = offset => new Date(Date.now() + offset * 864e5).toISOString().slice(0, 10);

function seed() {
  const now = new Date().toISOString();
  const b = (id, name, age, disability, aid, state, story) =>
    ({ id, name, age, disability, aid, cost: AIDS[aidKeyByName(aid)].price, raised: 0, state, story, delivered: false, updates: [], createdAt: now });
  return {
    campaign: {
      goal: 500000, baseRaised: 0, basePeople: 0, baseOpenApplications: 0,
      baseline: { chair: 0, crutch: 0, trike: 0, limb: 0, cane: 0 },
      baseSupporters: [],
    },
    beneficiaries: [
      b(1, 'Rajesh', 34, 'Amputee', 'Artificial Limb', 'Punjab', 'A bus conductor who lost his lower leg. An artificial limb would let him return to full-time work.'),
      b(2, 'Meena', 12, 'Cerebral palsy', 'Wheelchair', 'Bihar', 'Meena needs a supportive chair so she can sit with classmates and keep up with lessons.'),
      b(3, 'Mohan', 45, 'Paralysis', 'Tricycle', 'Uttar Pradesh', 'Mohan repairs phones but cannot get to customers. A tricycle would triple his daily reach.'),
      b(4, 'Sunita', 52, 'Paralysis', 'Wheelchair', 'Rajasthan', 'A seamstress who stopped working after a fall. A wheelchair would let her return to her workshop.'),
      b(5, 'Lakshmi', 41, 'Blindness', 'White Cane', 'Odisha', 'Lakshmi weaves baskets and sells them at the market. A cane would help her travel there safely on her own.'),
    ],
    nextBeneficiaryId: 6,
    donations: [], applications: [], volunteers: [], users: [],
    shifts: [
      { id: 's1', title: 'Wheelchair assembly day', role: 'Delivery and logistics', date: isoDay(5), time: '09:00–13:00', location: 'Central warehouse', capacity: 8, signups: [] },
      { id: 's2', title: 'Distribution camp', role: 'Event support', date: isoDay(9), time: '10:00–15:00', location: 'Community centre', capacity: 6, signups: [] },
      { id: 's3', title: 'Awareness walk', role: 'Awareness and outreach', date: isoDay(12), time: '08:30–12:30', location: 'City park', capacity: 10, signups: [] },
      { id: 's4', title: 'Community fundraising drive', role: 'Fundraising', date: isoDay(16), time: '11:00–16:00', location: 'Online and local markets', capacity: 10, signups: [] },
    ],
  };
}

function loadDb() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Could not read db.json, starting fresh:', error.message);
    return seed();
  }
}

function flush() {
  clearTimeout(saveTimer);
  saveTimer = null;
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function save() { if (!saveTimer) saveTimer = setTimeout(flush, 100); }

db = loadDb();
db.inKind = db.inKind || [];

/* --------------------------------------------------------------- secrets/auth */
function loadSecret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  const file = path.join(DATA_DIR, 'secret.key');
  try { return fs.readFileSync(file, 'utf8').trim(); } catch (e) { /* create below */ }
  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}
const SECRET = loadSecret();

const b64 = buf => Buffer.from(buf).toString('base64url');
function sign(payload) {
  const body = b64(JSON.stringify(payload));
  const mac = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  return body + '.' + mac;
}
function verify(token) {
  if (typeof token !== 'string') return null;
  const [body, mac] = token.split('.');
  if (!body || !mac) return null;
  const expected = crypto.createHmac('sha256', SECRET).update(body).digest();
  const given = Buffer.from(mac, 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    return payload.exp > Date.now() ? payload : null;
  } catch (e) { return null; }
}

async function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const key = await scrypt(password, salt, 64);
  return `${salt}:${key.toString('hex')}`;
}
async function checkPassword(password, stored) {
  const [salt, hash] = String(stored).split(':');
  const key = await scrypt(password, salt || 'x', 64);
  const expected = Buffer.from(hash || '', 'hex');
  return expected.length === key.length && crypto.timingSafeEqual(key, expected);
}

async function ensureAdmin() {
  if (db.users.some(u => u.role === 'admin')) return;
  const email = (process.env.ADMIN_EMAIL || 'admin@rollforward.local').toLowerCase();
  const generated = !process.env.ADMIN_PASSWORD;
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  db.users.push({ id: newId(), name: 'Programme Admin', email, role: 'admin', passwordHash: await hashPassword(password), createdAt: new Date().toISOString() });
  flush();
  console.log(`\n  Admin account created: ${email}${generated ? '  password: ' + password : ''}`);
  if (generated) console.log('  (shown once; set ADMIN_PASSWORD to choose your own)\n');
}

/* -------------------------------------------------------------------- helpers */
class HttpError extends Error {
  constructor(status, message, fields) { super(message); this.status = status; this.fields = fields; }
}
const newId = () => crypto.randomBytes(8).toString('hex');
const refCode = prefix => prefix + '-' + crypto.randomBytes(4).toString('hex').toUpperCase();
const str = (v, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 160;
const firstName = full => String(full).split(/[ ,]/)[0];
const sum = (list, pick) => list.reduce((total, item) => total + pick(item), 0);

function failIf(errors, message = 'Please fix the highlighted fields.') {
  if (Object.keys(errors).length) throw new HttpError(400, message, errors);
}

const PHONE_RE = /^\+?[0-9][0-9\s\-().]{6,19}$/;
const POSTCODE_RE = /^[A-Za-z0-9][A-Za-z0-9\s-]{2,13}$/;
/* Shared contact + billing/postal address validation (flat field names so errors map to form inputs). */
function parseContact(body, errors) {
  const phone = str(body.phone, 25);
  const address = { line1: str(body.line1, 120), line2: str(body.line2, 120), city: str(body.city, 80), state: str(body.state, 80), postcode: str(body.postcode, 16), country: str(body.country, 60) };
  if (!PHONE_RE.test(phone) || phone.replace(/\D/g, '').length < 7) errors.phone = 'Enter a phone number with country code, e.g. +91 98765 43210.';
  if (!address.line1) errors.line1 = 'Enter the street address.';
  if (!address.city) errors.city = 'Enter the city.';
  if (!POSTCODE_RE.test(address.postcode)) errors.postcode = 'Enter a valid postal / ZIP code.';
  if (!address.country) errors.country = 'Enter the country.';
  return { phone, address };
}

const publicUser = u => ({ id: u.id, name: u.name, email: u.email, role: u.role });

function beneficiaryView(b) {
  const remaining = Math.max(0, b.cost - b.raised);
  const donors = new Set(db.donations.filter(d => d.allocations.some(a => a.beneficiaryId === b.id)).map(d => d.userId || d.email)).size;
  return {
    id: b.id, name: b.name, age: b.age, disability: b.disability, aid: b.aid, aidKey: aidKeyByName(b.aid), cost: b.cost,
    raised: Math.min(b.raised, b.cost), remaining, percent: Math.round((Math.min(b.raised, b.cost) / b.cost) * 100),
    state: b.state, story: b.story, createdAt: b.createdAt, donors,
    status: b.delivered ? 'Delivered' : remaining === 0 ? 'Funded' : 'Seeking funds',
    updates: [...b.updates].reverse(),
  };
}

function totalRaised() { return db.campaign.baseRaised + sum(db.donations, d => d.amount); }

function receiptView(d) {
  return {
    id: d.id, createdAt: d.createdAt, name: d.name, email: d.email, item: itemLabel(d), option: d.option,
    phone: d.phone, billing: d.billing, quantity: d.quantity, amount: d.amount, dedication: d.dedication, message: d.message, anonymous: d.anonymous,
    allocations: d.allocations.map(a => ({
      amount: a.amount,
      to: a.beneficiaryId ? (db.beneficiaries.find(b => b.id === a.beneficiaryId) || {}).name || 'Beneficiary' : 'General fund (next matching request)',
      beneficiaryId: a.beneficiaryId,
    })),
  };
}

/* Money goes to the chosen person first, then to others who need the same aid
   (closest to complete first). Anything left over joins the general fund. */
function allocate(optionKey, amount, preferredId) {
  const open = b => b.cost - b.raised;
  const preferred = db.beneficiaries.find(b => b.id === preferredId);
  const sameAid = b => !AIDS[optionKey] || b.aid === AIDS[optionKey].name; // amount-only gifts help anyone
  const matching = db.beneficiaries
    .filter(b => b !== preferred && sameAid(b) && open(b) > 0)
    .sort((a, b) => open(a) - open(b));
  const queue = [...(preferred ? [preferred] : []), ...matching];
  let left = amount;
  const allocations = [];
  for (const b of queue) {
    const take = Math.min(open(b), left);
    if (take > 0) { b.raised += take; left -= take; allocations.push({ beneficiaryId: b.id, amount: take }); }
    if (!left) break;
  }
  if (left) allocations.push({ beneficiaryId: null, amount: left });
  return allocations;
}

/* --------------------------------------------------------------------- router */
const routes = [];
function route(method, pattern, opts, handler) {
  if (typeof opts === 'function') { handler = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, opts, handler });
}

const buckets = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const hits = (buckets.get(key) || []).filter(t => now - t < windowMs);
  hits.push(now);
  buckets.set(key, hits);
  return hits.length > max;
}
setInterval(() => { const cutoff = Date.now() - 120000; for (const [k, v] of buckets) if (!v.some(t => t > cutoff)) buckets.delete(k); }, 60000).unref();

function parseCookies(header = '') {
  return Object.fromEntries(header.split(';').map(p => p.trim().split(/=(.*)/s).slice(0, 2)).filter(p => p[0]));
}
function currentUser(req) {
  const payload = verify(parseCookies(req.headers.cookie).rf_session);
  return payload ? db.users.find(u => u.id === payload.uid) || null : null;
}
function sessionCookie(req, value, maxAge) {
  const secure = process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https';
  return `rf_session=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 100 * 1024) { reject(new HttpError(413, 'Request too large.')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const text = Buffer.concat(chunks).toString();
      if (!text) return resolve({});
      try { const parsed = JSON.parse(text); resolve(parsed && typeof parsed === 'object' ? parsed : {}); }
      catch (e) { reject(new HttpError(400, 'Invalid JSON.')); }
    });
    req.on('error', reject);
  });
}

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'",
};

function sendJson(res, status, data, extra = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, { ...SECURITY_HEADERS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra });
  res.end(body);
}

async function handleApi(req, res, url) {
  const method = req.method;
  const ip = process.env.TRUST_PROXY === '1' ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress : req.socket.remoteAddress;
  try {
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin;
      if (origin) { let host; try { host = new URL(origin).host; } catch (e) { host = ''; } if (host !== req.headers.host) throw new HttpError(403, 'Cross-origin request blocked.'); }
      if (!String(req.headers['content-type'] || '').startsWith('application/json')) throw new HttpError(415, 'Content-Type must be application/json.');
    }
    const match = routes.map(r => ({ r, m: r.method === method && url.pathname.match(r.re) })).find(x => x.m);
    if (!match) throw new HttpError(404, 'Not found.');
    const { r, m } = match;
    if (r.opts.limit && limited(`${r.method} ${r.re.source}:${ip}`,r.opts.limit[1], 60000)) throw new HttpError(429, 'Too many requests. Please wait a minute and try again.');

    const user = currentUser(req);
    if (r.opts.auth && !user) throw new HttpError(401, 'Please sign in first.');
    if (r.opts.admin && (!user || user.role !== 'admin')) throw new HttpError(403, 'Administrators only.');

    const ctx = {
      req, res, user, ip, status: 200, headers: {},
      params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])),
      query: Object.fromEntries(url.searchParams),
      body: method === 'GET' ? {} : await readBody(req),
    };
    const result = await r.handler(ctx);
    if (result && result.raw !== undefined) {
      res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': result.type, 'Content-Disposition': `attachment; filename="${result.filename}"`, 'Cache-Control': 'no-store' });
      return res.end(result.raw);
    }
    sendJson(res, ctx.status, result === undefined ? { ok: true } : result, ctx.headers);
  } catch (error) {
    if (error instanceof HttpError) return sendJson(res, error.status, { error: error.message, fields: error.fields || {} });
    console.error(error);
    sendJson(res, 500, { error: 'Unexpected server error.' });
  }
}

/* ------------------------------------------------------------- public routes */
route('GET', '/api/health', () => ({ ok: true }));

route('GET', '/api/catalogue', () => ({ accessoryTypes: ACCESSORY_TYPES, conditions: CONDITIONS, methods: METHODS, inKindStatuses: IK_STATUSES, aids: AIDS, states: INDIAN_STATES, minGift: MIN_GIFT, maxGift: MAX_GIFT, disabilities: DISABILITIES, volunteerRoles: VOLUNTEER_ROLES, statuses: APP_STATUSES }));

route('GET', '/api/campaign', () => {
  const c = db.campaign;
  const donated = key => sum(db.donations.filter(d => d.option === key), d => d.quantity);
  const byType = Object.keys(AIDS).map(key => ({ key, label: AIDS[key].name, count: c.baseline[key] + donated(key) }));
  const aidsFunded = sum(byType, t => t.count);
  const raised = totalRaised();
  const open = db.applications.filter(a => ['Received', 'Referral checked', 'Assessed'].includes(a.status)).length;
  const need = sum(db.beneficiaries, b => Math.max(0, b.cost - b.raised));
  return {
    goal: c.goal, raised, percent: Math.min(100, Math.round((raised / c.goal) * 100)),
    aidsFunded, byType, peopleSupported: c.basePeople + aidsFunded, openApplications: c.baseOpenApplications + open,
    outstandingNeed: need, seeking: db.beneficiaries.filter(b => b.raised < b.cost).length,
    delivered: db.beneficiaries.filter(b => b.delivered).map(beneficiaryView).slice(0, 6),
    itemsReceived: sum(db.inKind.filter(k => IK_RECEIVED.includes(k.status)), k => sum(k.items, i => i.quantity)),
    split: { equipment: 90, delivery: 10 },
  };
});

route('GET', '/api/supporters', () => {
  const money = db.donations.map(d => ({ name: d.anonymous ? 'Anonymous supporter' : d.name, detail: `₹${d.amount.toLocaleString('en-IN')}`, at: d.createdAt }));
  const goods = db.inKind.map(k => ({ name: k.anonymous ? 'Anonymous supporter' : (k.organisation || k.name), detail: `${sum(k.items, i => i.quantity)} item(s)`, at: k.createdAt }));
  const real = [...money, ...goods].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 8);
  const filler = db.campaign.baseSupporters.map(name => ({ name, detail: '' }));
  return [...real, ...filler].slice(0, 8);
});

route('GET', '/api/beneficiaries', ({ query }) => {
  const q = str(query.q, 80).toLowerCase();
  let list = db.beneficiaries.map(beneficiaryView).filter(b =>
    (!query.disability || b.disability === query.disability) &&
    (!query.aid || b.aid === query.aid) &&
    (query.hideFunded !== '1' || b.status === 'Seeking funds') &&
    (b.name + ' ' + b.state + ' ' + b.disability + ' ' + b.story).toLowerCase().includes(q));
  const sorts = {
    closest: (a, b) => (a.status === 'Seeking funds' ? 0 : 1) - (b.status === 'Seeking funds' ? 0 : 1) || a.remaining - b.remaining,
    least:   (a, b) => a.percent - b.percent,
    cheapest: (a, b) => a.cost - b.cost,
    newest:  (a, b) => b.id - a.id,
  };
  list.sort(sorts[query.sort] || sorts.closest);
  return list;
});

route('GET', '/api/beneficiaries/:id', ({ params }) => {
  const b = db.beneficiaries.find(x => x.id === Number(params.id));
  if (!b) throw new HttpError(404, 'Beneficiary not found.');
  return beneficiaryView(b);
});

route('POST', '/api/donations', { limit: ['write', 20] }, ctx => {
  const { body, user } = ctx;
  const byAmount = body.mode === 'amount';
  const option = byAmount ? GENERAL : str(body.option, 20);
  const quantity = byAmount ? 0 : Math.floor(Number(body.quantity));
  const name = str(body.name, 100) || (user && user.name) || '';
  const email = (str(body.email, 160) || (user && user.email) || '').toLowerCase();
  const preferred = Number(body.beneficiaryId) || 0;
  const errors = {};
  let amount = 0;
  if (byAmount) {
    amount = Math.floor(Number(body.amount));
    if (!(amount >= MIN_GIFT && amount <= MAX_GIFT)) errors.amount = `Enter an amount from ₹${MIN_GIFT.toLocaleString('en-IN')} to ₹${MAX_GIFT.toLocaleString('en-IN')}.`;
  } else {
    if (!AIDS[option]) errors.option = 'Choose what to fund.';
    if (!(quantity >= 1 && quantity <= 50)) errors.quantity = 'Enter a quantity from 1 to 50.';
  }
  if (!name) errors.name = 'Enter your name.';
  if (!isEmail(email)) errors.email = 'Enter a valid email, like name@example.com.';
  const { phone, address } = parseContact(body, errors);
  const target = preferred ? db.beneficiaries.find(b => b.id === preferred) : null;
  if (preferred && !target) errors.beneficiaryId = 'That beneficiary does not exist.';
  else if (target && target.raised >= target.cost) errors.beneficiaryId = `${firstName(target.name)} is already fully funded. Choose another person or \"Any beneficiary\".`;
  failIf(errors);

  if (!byAmount) amount = AIDS[option].price * quantity;
  const donation = {
    id: refCode('RF'), userId: user ? user.id : null, name, email, phone, billing: address, option, quantity, amount,
    anonymous: !!body.anonymous, dedication: str(body.dedication, 120), message: str(body.message, 300),
    createdAt: new Date().toISOString(), allocations: allocate(option, amount, preferred),
  };
  db.donations.push(donation);
  save();
  ctx.status = 201;
  return receiptView(donation);
});

route('POST', '/api/applications', { limit: ['write', 10] }, ({ body, user }) => {
  const a = {
    name: str(body.name, 100), age: Math.floor(Number(body.age)), state: str(body.state, 40), contact: str(body.contact, 160),
    disability: str(body.disability, 40), aid: str(body.aid, 40), referrer: str(body.referrer, 160), story: str(body.story, 1000),
  };
  const errors = {};
  if (!a.name) errors.name = 'Enter the applicant name.';
  if (!(a.age >= 1 && a.age <= 110)) errors.age = 'Enter an age from 1 to 110.';
  if (!INDIAN_STATES.includes(a.state)) errors.state = 'Choose your state.';
  if (!a.contact) errors.contact = 'Enter a phone number or email so we can reach you.';
  if (!DISABILITIES.includes(a.disability)) errors.disability = 'Choose a disability type.';
  if (!aidKeyByName(a.aid)) errors.aid = 'Choose the aid needed.';
  if (!a.referrer) errors.referrer = 'Enter the referring clinic, NGO or doctor.';
  if (a.story.length < 40) errors.story = 'Write at least 40 characters so reviewers understand the need.';
  if (!body.consent) errors.consent = 'Consent is required for verification.';
  failIf(errors);

  const now = new Date().toISOString();
  const app = { ref: refCode('AP'), userId: user ? user.id : null, ...a, status: 'Received', beneficiaryId: null, createdAt: now, history: [{ status: 'Received', note: 'Application received.', at: now }] };
  db.applications.push(app);
  save();
  return { ref: app.ref, status: app.status };
});

const appView = a => ({ ref: a.ref, name: a.name, aid: a.aid, status: a.status, createdAt: a.createdAt, history: a.history });

route('POST', '/api/applications/track', { limit: ['auth', 10] }, ({ body }) => {
  const ref = str(body.ref, 30).toUpperCase();
  const contact = str(body.contact, 160).toLowerCase();
  const app = db.applications.find(a => a.ref === ref && a.contact.toLowerCase() === contact);
  if (!app) throw new HttpError(404, 'No application matches that reference and contact detail.');
  return appView(app);
});

route('POST', '/api/volunteers', { limit: ['write', 10] }, ({ body, user }) => {
  const v = { name: str(body.name, 100), email: str(body.email, 160).toLowerCase(), role: str(body.role, 60), times: Array.isArray(body.times) ? body.times.filter(t => ['Weekdays', 'Weekends', 'Evenings'].includes(t)) : [] };
  const errors = {};
  if (!v.name) errors.name = 'Enter your name.';
  if (!isEmail(v.email)) errors.email = 'Enter a valid email.';
  if (!VOLUNTEER_ROLES.includes(v.role)) errors.role = 'Choose a role.';
  if (!v.times.length) errors.times = 'Choose at least one availability option.';
  failIf(errors);
  db.volunteers.push({ id: newId(), userId: user ? user.id : null, ...v, createdAt: new Date().toISOString() });
  save();
  return { ok: true };
});

const shiftView = (s, user) => ({
  id: s.id, title: s.title, role: s.role, date: s.date, time: s.time, location: s.location, capacity: s.capacity,
  taken: s.signups.length, joined: !!user && s.signups.some(x => x.userId === user.id),
});

route('GET', '/api/shifts', ({ user }) => {
  const today = isoDay(0);
  return db.shifts.filter(s => s.date >= today).sort((a, b) => a.date.localeCompare(b.date)).map(s => shiftView(s, user));
});

/* ------------------------------------------------------------------- accounts */
function startSession(req, user) {
  const token = sign({ uid: user.id, exp: Date.now() + SESSION_DAYS * 864e5 });
  return { 'Set-Cookie': sessionCookie(req, token, SESSION_DAYS * 86400) };
}

route('POST', '/api/auth/signup', { limit: ['auth', 8] }, async ctx => {
  const { body, req } = ctx;
  const name = str(body.name, 100), email = str(body.email, 160).toLowerCase();
  const password = typeof body.password === 'string' ? body.password : '';
  const role = ROLES.includes(body.role) ? body.role : 'donor';
  const errors = {};
  if (name.length < 2) errors.name = 'Enter your full name.';
  if (!isEmail(email)) errors.email = 'Enter a valid email, like name@example.com.';
  if (password.length < 8 || password.length > 200) errors.password = 'Use at least 8 characters.';
  if (!body.terms) errors.terms = 'Accept the terms to continue.';
  failIf(errors);
  if (db.users.some(u => u.email === email)) throw new HttpError(409, 'An account with this email exists. Sign in instead.', { email: 'An account with this email exists. Sign in instead.' });
  const user = { id: newId(), name, email, role, passwordHash: await hashPassword(password), createdAt: new Date().toISOString() };
  db.users.push(user);
  save();
  ctx.headers = startSession(req, user);
  ctx.status = 201;
  return publicUser(user);
});

const DUMMY_HASH = 'x:' + '0'.repeat(128);
route('POST', '/api/auth/login', { limit: ['auth', 10] }, async ctx => {
  const email = str(ctx.body.email, 160).toLowerCase();
  const password = typeof ctx.body.password === 'string' ? ctx.body.password : '';
  const user = db.users.find(u => u.email === email);
  const ok = await checkPassword(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !ok) throw new HttpError(401, 'Email or password is incorrect.');
  ctx.headers = startSession(ctx.req, user);
  return publicUser(user);
});

route('POST', '/api/auth/logout', ctx => { ctx.headers = { 'Set-Cookie': sessionCookie(ctx.req, '', 0) }; });

route('GET', '/api/me', ({ user }) => (user ? publicUser(user) : null));

route('PATCH', '/api/me', { auth: true }, ({ user, body }) => {
  const name = str(body.name, 100);
  failIf(name.length < 2 ? { name: 'Enter your full name.' } : {});
  user.name = name;
  save();
  return publicUser(user);
});

route('POST', '/api/me/password', { auth: true, limit: ['auth', 8] }, async ({ user, body }) => {
  const next = typeof body.next === 'string' ? body.next : '';
  const errors = {};
  if (!(await checkPassword(String(body.current || ''), user.passwordHash))) errors.current = 'Current password is incorrect.';
  if (next.length < 8) errors.next = 'Use at least 8 characters.';
  failIf(errors);
  user.passwordHash = await hashPassword(next);
  save();
});

route('POST', '/api/me/delete', { auth: true, limit: ['auth', 5] }, async ctx => {
  const { user, body } = ctx;
  if (user.role === 'admin') throw new HttpError(400, 'The administrator account cannot be deleted here.');
  if (!(await checkPassword(String(body.password || ''), user.passwordHash))) throw new HttpError(400, 'Password is incorrect.', { password: 'Password is incorrect.' });
  db.users = db.users.filter(u => u.id !== user.id);
  db.donations.forEach(d => { if (d.userId === user.id) d.userId = null; });
  db.applications.forEach(a => { if (a.userId === user.id) a.userId = null; });
  db.inKind.forEach(k => { if (k.userId === user.id) k.userId = null; });
  db.shifts.forEach(s => { s.signups = s.signups.filter(x => x.userId !== user.id); });
  save();
  ctx.headers = { 'Set-Cookie': sessionCookie(ctx.req, '', 0) };
});

route('GET', '/api/me/donations', { auth: true }, ({ user }) =>
  db.donations.filter(d => d.userId === user.id || d.email === user.email).reverse().map(receiptView));

route('GET', '/api/me/impact', { auth: true }, ({ user }) => {
  const ids = new Set();
  db.donations.filter(d => d.userId === user.id || d.email === user.email).forEach(d => d.allocations.forEach(a => a.beneficiaryId && ids.add(a.beneficiaryId)));
  return db.beneficiaries.filter(b => ids.has(b.id)).map(beneficiaryView);
});

route('GET', '/api/me/applications', { auth: true }, ({ user }) =>
  db.applications.filter(a => a.userId === user.id || a.contact.toLowerCase() === user.email).reverse().map(appView));

route('GET', '/api/me/shifts', { auth: true }, ({ user }) =>
  db.shifts.filter(s => s.signups.some(x => x.userId === user.id)).sort((a, b) => a.date.localeCompare(b.date)).map(s => shiftView(s, user)));

route('GET', '/api/donations/:id', { auth: true }, ({ user, params }) => {
  const d = db.donations.find(x => x.id === params.id);
  if (!d || !(user.role === 'admin' || d.userId === user.id || d.email === user.email)) throw new HttpError(404, 'Receipt not found.');
  return receiptView(d);
});

route('POST', '/api/shifts/:id/join', { auth: true }, ({ user, params }) => {
  const s = db.shifts.find(x => x.id === params.id);
  if (!s) throw new HttpError(404, 'Shift not found.');
  if (s.signups.some(x => x.userId === user.id)) throw new HttpError(409, 'You have already joined this shift.');
  if (s.signups.length >= s.capacity) throw new HttpError(409, 'This shift is full.');
  s.signups.push({ userId: user.id, name: user.name, email: user.email });
  save();
  return shiftView(s, user);
});

route('POST', '/api/shifts/:id/leave', { auth: true }, ({ user, params }) => {
  const s = db.shifts.find(x => x.id === params.id);
  if (!s) throw new HttpError(404, 'Shift not found.');
  s.signups = s.signups.filter(x => x.userId !== user.id);
  save();
  return shiftView(s, user);
});

/* ---------------------------------------------------------------------- admin */
route('GET', '/api/admin/summary', { admin: true }, () => {
  const days = Array.from({ length: 14 }, (_, i) => isoDay(i - 13));
  const perDay = days.map(day => ({ day, amount: sum(db.donations.filter(d => d.createdAt.startsWith(day)), d => d.amount) }));
  const needByAid = Object.keys(AIDS).map(key => ({
    label: AIDS[key].name,
    need: sum(db.beneficiaries.filter(b => b.aid === AIDS[key].name), b => Math.max(0, b.cost - b.raised)),
  }));
  return {
    raised: totalRaised(), donations: db.donations.length, donationTotal: sum(db.donations, d => d.amount),
    average: db.donations.length ? Math.round(sum(db.donations, d => d.amount) / db.donations.length) : 0,
    users: db.users.length, volunteers: db.volunteers.length,
    inKindByStatus: IK_STATUSES.map(st => ({ status: st, count: db.inKind.filter(k => k.status === st).length })),
    generalFund: sum(db.donations.flatMap(d => d.allocations).filter(a => !a.beneficiaryId), a => a.amount),
    applicationsByStatus: APP_STATUSES.map(s => ({ status: s, count: db.applications.filter(a => a.status === s).length })),
    awaitingDelivery: db.beneficiaries.filter(b => b.raised >= b.cost && !b.delivered).map(beneficiaryView),
    perDay, needByAid,
  };
});

route('GET', '/api/admin/applications', { admin: true }, () => [...db.applications].reverse());

route('PATCH', '/api/admin/applications/:ref', { admin: true }, ({ params, body }) => {
  const app = db.applications.find(a => a.ref === params.ref);
  if (!app) throw new HttpError(404, 'Application not found.');
  const status = str(body.status, 30), note = str(body.note, 300), publicStory = str(body.publicStory, 400);
  const errors = {};
  if (!APP_STATUSES.includes(status)) errors.status = 'Choose a valid status.';
  if (status === 'Approved' && !app.beneficiaryId && publicStory.length < 20) errors.publicStory = 'Write a short public story (no surnames, addresses or phone numbers) before approving.';
  failIf(errors);
  if (status === 'Approved' && !app.beneficiaryId) {
    const id = db.nextBeneficiaryId++;
    db.beneficiaries.push({
      id, name: firstName(app.name), age: app.age, disability: app.disability, aid: app.aid, cost: AIDS[aidKeyByName(app.aid)].price,
      raised: 0, state: app.state, story: publicStory, delivered: false, updates: [], createdAt: new Date().toISOString(),
    });
    app.beneficiaryId = id;
  }
  if (status !== app.status || note) app.history.push({ status, note: note || `Status changed to ${status}.`, at: new Date().toISOString() });
  app.status = status;
  save();
  return app;
});

route('GET', '/api/admin/donations', { admin: true }, () => [...db.donations].reverse().map(d => ({ ...receiptView(d), userId: d.userId })));

const addressLine = a => (a ? [a.line1, a.line2, a.city, a.state, a.postcode, a.country].filter(Boolean).join(', ') : '');
const csvCell = v => {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise spreadsheet formulas
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
route('GET', '/api/admin/donations.csv', { admin: true }, () => {
  const rows = [['Receipt', 'Date', 'Name', 'Email', 'Phone', 'Billing address', 'Item', 'Quantity', 'Amount INR', 'Anonymous', 'Dedication', 'Allocation']];
  db.donations.forEach(d => rows.push([d.id, d.createdAt, d.name, d.email, d.phone, addressLine(d.billing), itemLabel(d), d.quantity || '', d.amount, d.anonymous ? 'yes' : 'no', d.dedication,
    receiptView(d).allocations.map(a => `${a.to}: ₹${a.amount}`).join('; ')]));
  return { raw: rows.map(r => r.map(csvCell).join(',')).join('\n'), type: 'text/csv; charset=utf-8', filename: 'donations.csv' };
});

route('GET', '/api/admin/volunteers', { admin: true }, () => ({
  interests: [...db.volunteers].reverse(),
  shifts: db.shifts.map(s => ({ ...shiftView(s, null), signups: s.signups })),
}));

route('GET', '/api/admin/beneficiaries', { admin: true }, () => db.beneficiaries.map(beneficiaryView));

route('POST', '/api/admin/beneficiaries/:id/updates', { admin: true }, ({ params, body }) => {
  const b = db.beneficiaries.find(x => x.id === Number(params.id));
  if (!b) throw new HttpError(404, 'Beneficiary not found.');
  const text = str(body.text, 300);
  const errors = {};
  if (text.length < 5) errors.text = 'Write a short update donors will see.';
  if (body.delivered && b.raised < b.cost) errors.delivered = 'Only fully funded aids can be marked delivered.';
  failIf(errors);
  b.updates.push({ at: new Date().toISOString(), text });
  if (body.delivered) b.delivered = true;
  save();
  return beneficiaryView(b);
});

route('POST', '/api/admin/shifts', { admin: true }, ({ body }) => {
  const s = { id: 's' + newId(), title: str(body.title, 100), role: str(body.role, 60), date: str(body.date, 10), time: str(body.time, 40), location: str(body.location, 100), capacity: Math.floor(Number(body.capacity)), signups: [] };
  const errors = {};
  if (!s.title) errors.title = 'Enter a title.';
  if (!VOLUNTEER_ROLES.includes(s.role)) errors.role = 'Choose a role.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s.date)) errors.date = 'Choose a date.';
  if (!s.time) errors.time = 'Enter a time range.';
  if (!s.location) errors.location = 'Enter a location.';
  if (!(s.capacity >= 1 && s.capacity <= 200)) errors.capacity = 'Enter a capacity from 1 to 200.';
  failIf(errors);
  db.shifts.push(s);
  save();
  return shiftView(s, null);
});

/* ------------------------------------------------------- accessory (in-kind) gifts */
const inKindView = k => ({
  ref: k.ref, name: k.name, organisation: k.organisation, email: k.email, phone: k.phone, address: k.address, items: k.items,
  method: k.method, notes: k.notes, anonymous: k.anonymous, status: k.status, pickupDate: k.pickupDate, createdAt: k.createdAt, history: k.history,
  totalItems: sum(k.items, i => i.quantity),
});

route('POST', '/api/inkind', { limit: ['write', 10] }, ctx => {
  const { body, user } = ctx;
  const errors = {};
  const name = str(body.name, 100) || (user && user.name) || '';
  const email = (str(body.email, 160) || (user && user.email) || '').toLowerCase();
  const method = str(body.method, 40);
  if (!name) errors.name = 'Enter your name.';
  if (!isEmail(email)) errors.email = 'Enter a valid email, like name@example.com.';
  const { phone, address } = parseContact(body, errors);
  if (!METHODS.includes(method)) errors.method = 'Choose how the items will reach us.';
  const items = (Array.isArray(body.items) ? body.items : []).slice(0, 10).map(i => ({
    type: str(i && i.type, 60), description: str(i && i.description, 200), quantity: Math.floor(Number(i && i.quantity)), condition: str(i && i.condition, 20),
  }));
  const badItem = items.some(i => !ACCESSORY_TYPES.includes(i.type) || !(i.quantity >= 1 && i.quantity <= 500) || !CONDITIONS.includes(i.condition) || (i.type === 'Other' && i.description.length < 3));
  if (!items.length || badItem) errors.items = 'Add at least one item with a type, a quantity from 1 to 500 and a condition. "Other" needs a short description.';
  if (!body.consent) errors.consent = 'Please confirm the items are yours to give and are clean and safe to use.';
  failIf(errors);
  const now = new Date().toISOString();
  const k = {
    ref: refCode('IK'), userId: user ? user.id : null, name, email, organisation: str(body.organisation, 120), phone, address, items, method,
    notes: str(body.notes, 300), anonymous: !!body.anonymous, status: 'Pledged', pickupDate: '', createdAt: now,
    history: [{ status: 'Pledged', note: 'Pledge received. A coordinator will contact you to arrange hand-over.', at: now }],
  };
  db.inKind.push(k);
  save();
  ctx.status = 201;
  return inKindView(k);
});

route('POST', '/api/inkind/track', { limit: ['auth', 10] }, ({ body }) => {
  const ref = str(body.ref, 30).toUpperCase(), email = str(body.email, 160).toLowerCase();
  const k = db.inKind.find(x => x.ref === ref && x.email === email);
  if (!k) throw new HttpError(404, 'No pledge matches that reference and email.');
  return inKindView(k);
});

route('GET', '/api/me/inkind', { auth: true }, ({ user }) =>
  db.inKind.filter(k => k.userId === user.id || k.email === user.email).reverse().map(inKindView));

route('GET', '/api/admin/inkind', { admin: true }, () => [...db.inKind].reverse().map(inKindView));

route('PATCH', '/api/admin/inkind/:ref', { admin: true }, ({ params, body }) => {
  const k = db.inKind.find(x => x.ref === params.ref);
  if (!k) throw new HttpError(404, 'Pledge not found.');
  const status = str(body.status, 30), note = str(body.note, 300), pickupDate = str(body.pickupDate, 10);
  const errors = {};
  if (!IK_STATUSES.includes(status)) errors.status = 'Choose a valid status.';
  if (status === 'Arrangement confirmed' && !/^\d{4}-\d{2}-\d{2}$/.test(pickupDate)) errors.pickupDate = 'Choose the pickup / drop-off date.';
  failIf(errors);
  if (pickupDate) k.pickupDate = pickupDate;
  const detail = status === 'Arrangement confirmed' ? `${note || 'Hand-over arranged.'} Date: ${k.pickupDate}.` : note;
  if (status !== k.status || note) k.history.push({ status, note: detail || `Status changed to ${status}.`, at: new Date().toISOString() });
  k.status = status;
  save();
  return inKindView(k);
});

route('GET', '/api/admin/inkind.csv', { admin: true }, () => {
  const rows = [['Ref', 'Date', 'Status', 'Name', 'Organisation', 'Email', 'Phone', 'Address', 'Method', 'Hand-over date', 'Items']];
  db.inKind.forEach(k => rows.push([k.ref, k.createdAt, k.status, k.name, k.organisation, k.email, k.phone, addressLine(k.address), k.method, k.pickupDate,
    k.items.map(i => `${i.quantity} x ${i.type} (${i.condition})${i.description ? ': ' + i.description : ''}`).join('; ')]));
  return { raw: rows.map(r => r.map(csvCell).join(',')).join('\n'), type: 'text/csv; charset=utf-8', filename: 'accessory-pledges.csv' };
});

/* -------------------------------------------------------------- static files */
const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };

function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch (e) { res.writeHead(400); return res.end(); }
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { ...SECURITY_HEADERS, 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) handleApi(req, res, url);
  else serveStatic(req, res, url);
});

ensureAdmin().then(() => {
  server.listen(PORT, () => console.log(`Roll Forward running at http://localhost:${PORT}`));
});

for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { flush(); process.exit(0); });

module.exports = { server };
